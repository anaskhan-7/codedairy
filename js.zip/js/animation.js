const btn1 = document.querySelector(".btn1");
const menu = document.querySelector(".menu");      
// btn1.onclick = (function(){
//     btn1.classList.toggle("new-btn");
//     menu.classList.toggle("new-menu");

// });

btn1.addEventListener("click",()=>{
  
  menu.classList.toggle("new-menu");
})


// const cir = document.querySelector(".circle");

// setInterval(anima, 1000);
// function anima() {
//   cir.classList.toggle("cir");
//   cir.style.transform = "translate3d(40px, 0px, 0px)";         
// }

// const cir2 = document.querySelector(".circle2");

// setInterval(ani, 1000);     
// function ani() {
//  cir2.classList.toggle("circle3");            
// }

// const motion = document.getElementById("circls");

// setInterval(mov, 1000);

// function mov(){
//  motion.classList.toggle("ani-cir2");
// }


// const motion2 = document.getElementById("move1");

// setInterval(mov2, 1000);

// function mov2(){
//  motion2.classList.toggle("ani-cir3");
// };


// const mot1 = document.getElementById("cir4");

// setInterval (mov4, 1000);

// function mov4(){
//   mot1.classList.toggle("cir-4")
// }

// const mot2 = document.getElementById("mov-5");

// setInterval (mov5, 1000);

// function mov5(){
//   mot2.classList.toggle("cir-5")
// }



  



